package CtrLayer;
import ModelLayer.*;
import java.util.*;

/**
 * The controller for the Sales
 *
 * @author Pien van den Abeele
 * @version 14-12-2018
 */
public class SaleCtr {
    PersonCtr personCtr = new PersonCtr();
    SaleContainer sc = SaleContainer.getInstance();
    ProductContainer proc = ProductContainer.getInstance();
    PersonContainer perc = PersonContainer.getInstance();
    
    /**
     * Creates a sale controller pannel
     */
    public SaleCtr() {
    }
    
    /**
     * Creates a new sale
     * 
     * @param employeeID       the ID of the employee who creates the sale
     * @param customerPhone    the phone number of the customer
     */
    public Sale createSale(int employeeID, String customerPhone) {
        boolean result = false;
        Sale s = new Sale(employeeID, customerPhone);
        sc.addSale(s);
        return s;
    }
    
    /**
     * Adds a new OrderLine to a sale
     * 
     * @param saleID        the ID of the sale you're adding the orderline to
     * @param productID     the ID of the product you're adding
     * @param quantity      the amount requested of the product 
     */
    public boolean addOrderLine(int saleID, int productID, int quantity) {
        Product p = proc.findProductByID(productID);
        if (p.getStock() >= quantity) {
            Sale s = findSale(saleID);
            s.addOrderLine(quantity, productID);
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Removes a OrderLine from a sale
     * 
     * @param saleID        the ID of the sale you're removing the orderline from
     * @param productID     the ID of the product you're removing
     */    
    public void removeOrderLine(int saleID, int productID) {
        Sale s = findSale(saleID);
        s.removeOrderLine(productID);
    }
    
    /**
     * Returns the total price of a sale
     * 
     * @param saleID    the ID of the sale
     */
    public double totalPrice(int saleID) {
        Sale s = findSale(saleID);
        double totalPrice = s.totalPrice();
        return totalPrice;
    }
    
    /**
     * Searches the HashSet sales for a sale based on ID.
     * 
     * @return returns either null or the specific sale
     * @param saleID  the ID of the sale 
     */
    public Sale findSale(int saleID) {
        return sc.findSale(saleID);
    }
    
    /**
     * Returns all the sales stored in the HashSet sales
     * 
     * @return  returns the sales
     */
    public HashSet<Sale> getAllSales() {
        HashSet<Sale> foundSales = sc.getSales();
        return foundSales;
    }
    
    /**
     * Prints out all the sales stored in SaleContainer
     */
    public void printAllSales() {
        Iterator<Sale> it = getAllSales().iterator();
        Sale sale = null;
        System.out.println("\f" );
        while (it.hasNext()) {
            sale = it.next();
            System.out.println("#--------------------------------------#");
            System.out.println("  Sale ID:  " + sale.getSaleID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Employee" );
            System.out.println("  ID:       " + sale.getEmployeeID());
            System.out.println("  Name:     " + personCtr.findEmployee(sale.getEmployeeID()).getName());
            System.out.println("|--------------------------------------|");
            System.out.println("  Customer ");
            System.out.println("  Name:     " + personCtr.findCustomer(sale.getCustomerPhone()).getName());
            System.out.println("  Phone:    " + sale.getCustomerPhone());
            System.out.println("|--------------------------------------|");
            Iterator<OrderLine> oit = sale.getBasket().iterator();
            OrderLine orderLine = null;
            while (oit.hasNext()) {
                orderLine = oit.next();
                int prodID = orderLine.getProductID();
                Product prod = proc.findProductByID(prodID);
                System.out.println("  Product: " + prod.getProductName()+" @ $"+prod.getPrice());
                System.out.println("      x "+orderLine.getQuantity()+" = " + orderLine.calculateSubTotal());
            }
            System.out.println("|--------------------------------------|");
            System.out.println("| Total: $" + sale.totalPrice());
        }
        System.out.println("#--------------------------------------#");
    }
    
    /**
     * Prints out a sale found by sale ID
     * 
     * @param saleID         the ID of the sale
     */
    public void printSale(int saleID) {
        Sale sale = sc.findSale(saleID);
        System.out.println("\f#--------------------------------------#");
        System.out.println("  Sale ID: " + sale.getSaleID());
        if (sale.isPaid() == true) {
            System.out.println("  Paid:    Yes.");
        } 
        else {
            System.out.println("  Paid:    No.");
        }
        Iterator<OrderLine> oit = sale.getBasket().iterator();
        OrderLine orderLine = null;
        while (oit.hasNext()) {
                orderLine = oit.next();
                int prodID = orderLine.getProductID();
                Product prod = proc.findProductByID(prodID);
                System.out.println("  Product: " + prod.getProductName()+" @ $"+prod.getPrice());
                System.out.println("      x "+orderLine.getQuantity()+" = " + orderLine.calculateSubTotal());
            }
        System.out.println("  Total: $" + sale.totalPrice());
        System.out.println("#--------------------------------------#");
    }
    
    /**
     * Finalizes a sale, this method is used when the sale is done and paid for
     * 
     * @param saleID    the ID of the sale
     */
    public boolean finalizeSale(int saleID) {
        Sale s = findSale(saleID);
        s.finalizeSale();
        return true;
    }
    
    /**
     * Finds all the employee sales
     * 
     * @param employeeID    the ID of the employee in question
     * @return foundSales   returns all the sales found
     */
    public HashSet<Sale> findEmployeeSales (int employeeID) {
        SaleCtr scon = new SaleCtr();
        HashSet<Sale> foundSales = new HashSet();
        HashSet<Sale> allSales = getAllSales();
        Iterator<Sale> it = allSales.iterator();
        Sale sale = null;
        while (it.hasNext()) {
            sale = it.next();
            if (sale.getEmployeeID() == employeeID) {
                foundSales.add(sale);
            }
        }
        return foundSales;
    }
    
    /**
     * Finds all the customer sales
     * 
     * @param phone         the phone of the customer in question
     * @return foundSales   returns all the sales found
     */
    public HashSet<Sale> findCustomerSales (String phone) {
        SaleCtr scon = new SaleCtr();
        HashSet<Sale> foundSales = new HashSet();
        HashSet<Sale> allSales = getAllSales();
        Iterator<Sale> it = allSales.iterator();
        Sale sale = null;
        while (it.hasNext()) {
            sale = it.next();
            if (sale.getCustomerPhone().equals(phone)) {
                foundSales.add(sale);
            }
        }
        return foundSales;
    }

    /**
     * Prints out all the customer sales
     * 
     * @param phone         the phone of the customer in question
     */
    public void printCustomerSales(String phone) {
        Person p = perc.findCustomer(phone);
        Iterator<Sale> it = findCustomerSales(phone).iterator();
        Sale sale = null;
        while (it.hasNext()) {
            sale = it.next();
            System.out.println("#--------------------------------------#");
            System.out.println("| Sale ID: " + sale.getSaleID());
            Iterator<OrderLine> oit = sale.getBasket().iterator();
            OrderLine orderLine = null;
            while (oit.hasNext()) {
                orderLine = oit.next();
                int prodID = orderLine.getProductID();
                Product prod = proc.findProductByID(prodID);
                System.out.println("| Product: " + prod.getProductName()+" @ $"+prod.getPrice());
                System.out.println("|     x "+orderLine.getQuantity()+" = " + orderLine.calculateSubTotal());
            }
            System.out.println("| Total: $" + sale.totalPrice());
        }
        System.out.println("#--------------------------------------#");
    }
    
    /**
     * removes a sale from the sale container
     * 
     * @param saleID        the ID of the sale
     */
    public void removeSale(int saleID) {
        Sale s = findSale(saleID);
        sc.removeSale(s);
    }
    
    /**
     * Prints out all the employee sales
     * 
     * @param employeeID     the ID of the employee in question
     */
    public void printEmployeeSales(int employeeID) {
        Person p = perc.findEmployee(employeeID);
        Iterator<Sale> it = findEmployeeSales(employeeID).iterator();
        Sale sale = null;
        while (it.hasNext()) {
            sale = it.next();
            System.out.println("#--------------------------------------#");
            System.out.println("| Sale ID:  " + sale.getSaleID());
            Iterator<OrderLine> oit = sale.getBasket().iterator();
            OrderLine orderLine = null;
            while (oit.hasNext()) {
                orderLine = oit.next();
                int prodID = orderLine.getProductID();
                Product prod = proc.findProductByID(prodID);
                System.out.println("| Product: " + prod.getProductName()+" @ $"+prod.getPrice());
                System.out.println("|     x "+orderLine.getQuantity()+" = " + orderLine.calculateSubTotal());
            }
            System.out.println("| Total: $" + sale.totalPrice());
        }
        System.out.println("#--------------------------------------#");
    }   
}
