package CtrLayer;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SaleTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SaleTest
{
    private CtrLayer.SaleCtr saleCtr1;
    private CtrLayer.PersonCtr personCt1;
    private CtrLayer.ProductCtr productC1;

    
    
    

    
    
    
    
    

    /**
     * Default constructor for test class SaleTest
     */
    public SaleTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        saleCtr1 = new CtrLayer.SaleCtr();
        personCt1 = new CtrLayer.PersonCtr();
        personCt1.createCustomer(" Bob" , " 123" , " 123" );
        personCt1.createEmployee(" STeve" , "321" );
        productC1 = new CtrLayer.ProductCtr();
        productC1.createProduct("Door" , 12, 12.30);
        productC1.createProduct("Table" , 123, 14.50);
        saleCtr1.createSale(0, " 123" );
        saleCtr1.addOrderLine(0, 0, 3);
        saleCtr1.addOrderLine(0, 1, 5);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}

