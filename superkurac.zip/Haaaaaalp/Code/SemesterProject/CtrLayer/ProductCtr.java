package CtrLayer;
import ModelLayer.*;
import java.util.*;

/**
 * Controller for the Products.
 *
 * @author Pien van den Abeele
 * @version 14-12-2018
 */
public class ProductCtr {
    ProductContainer proc = ProductContainer.getInstance();

    /**
     * Creates a product controller pannel
     */
    public ProductCtr() {   
    }

    /**
     * Creates a new product
     * 
     * @param productname       name of the product created
     * @param stock             the amount in stock when created
     * @param price             the price of the product created
     */
    public Product createProduct(String productName, int stock, double price) {        
        Product p = new Product(productName, stock, price);
        proc.addProduct(p);
        return p;
    }

    /**
     * Removes a product from products, which is the list of all products.
     * 
     * @param productID  the ID of the product that is removed
     */
    public void removeProduct(int productID) {
        Product p = findProductByID(productID);
        proc.removeProduct(p);
    }

    /**
     * Searches the HashSet products for a product based on ID.
     * 
     * @return returns either null or the specific product
     * @param productID  the ID of the product 
     */
    public Product findProductByID(int productID) {
        return proc.findProductByID(productID);
    }

    /**
     * Searches the HashSet products for a product based on name.
     * 
     * @return returns either null or the specific product
     * @param productName  the name of the product 
     */
    public Product findProductByName(String productName) {
        return proc.findProductByName(productName);
    }

    /**
     * Updates the product name
     * 
     * @param productID         the ID of the product that's being changed
     * @param productName       the new name of the product
     */
    public void updateProductName(int productID, String productName) {
        Product p = findProductByID(productID);
        p.setProductName(productName);
    }

    /**
     * Updates the stock amount
     * 
     * @param productID         the ID of the product that's being changed
     * @param stock             the new stock of the product
     */
    public void updateStock(int productID, int stock) {
        Product p = findProductByID(productID);
        p.setStock(stock);
    }

    /**
     * Updates the price
     * 
     * @param productID         the ID of the product that's being changed
     * @param price             the new price of the product
     */
    public void updatePrice(int productID, double price) {
        Product p = findProductByID(productID);
        p.setPrice(price);
    }

    /**
     * Returns all the products stored in the HashSet products
     * 
     * @return  returns the products
     */
    public HashSet<Product> getAllProducts() {
        HashSet<Product> foundProducts = proc.getProducts();
        return foundProducts;
    }

    /**
     * Prints out all the products stored in ProductContainer
     */
    public void printAllProducts() {
        Iterator<Product> it = getAllProducts().iterator();
        Product product = null;
        while (it.hasNext()) {
            product = it.next();
            System.out.println("#--------------------------------------#");
            System.out.println("  Product: " + product.getProductName());            
            System.out.println("  Stock: " + product.getStock());     
            System.out.println("  Price: $" + product.getPrice());       
            System.out.println("  ID: " + product.getProductID());
            System.out.println("#--------------------------------------#");
        }
    }

    /**
     * Checks if the stock is a legit value
     * 
     * @param stock     The stock of the product
     */
    public void checkStockValue(int stock){
        Product product = null;
        if(stock<0) { 
            System.out.println("Stock cannot be negative. Enter a positive amount.");
        } else {
            product.getStock();
        }
    }
    
    /**
     * Checks if the price is a legit value
     * 
     * @param pricd     The price of the product
     */
    public void checkPriceValue(double price){
        Product product = null;
        if(price<0) {
            System.out.println("Price cannot be negative. Enter a positive one.");            
        } else {
            product.getPrice();
        }
    }
    
}
