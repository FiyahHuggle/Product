package CtrLayer;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PersonTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PersonTest
{
    private CtrLayer.PersonCtr personCt1;
    private CtrLayer.SaleCtr saleCtr1;
    private CtrLayer.ProductCtr productC1;

    
    
    

    

    /**
     * Default constructor for test class PersonTest
     */
    public PersonTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        personCt1 = new CtrLayer.PersonCtr();
        personCt1.createCustomer("Pien", "9000", "12345678");
        personCt1.createCustomer("Dora", "9001", "1");
        personCt1.createEmployee("Steven Teglman", "9000");
        saleCtr1 = new CtrLayer.SaleCtr();
        productC1 = new CtrLayer.ProductCtr();
        productC1.createProduct("Dongle", 99, 1.50);
        productC1.createProduct("Widget", 1, 5.99);
        saleCtr1.createSale(0, "12345678");
        saleCtr1.addOrderLine(0, 1, 1);
        saleCtr1.addOrderLine(0, 0, 25);
        saleCtr1.finalizeSale(0);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
