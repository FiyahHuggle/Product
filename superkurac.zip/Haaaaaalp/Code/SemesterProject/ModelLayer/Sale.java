package ModelLayer;
import java.util.*;

/**
 * Creating a Sale
 *
 * @author Pien van den Abeele
 * @version 14-12-2018
 */
public class Sale {
    private int saleID;
    private int employeeID;
    private String customerPhone;
    private boolean paid = false;
    private static int runningID = 0;
    private HashSet<OrderLine> basket;
    ProductContainer proc = ProductContainer.getInstance();
    
    /**
     * Create a new Sale
     * 
     * @param employeeID        the ID of the employee responsible of the sale
     * @param customerPhone     the phone number of the customer assigned to the sale
     */
    public Sale(int employeeID, String customerPhone) {
        this.employeeID = employeeID;
        this.customerPhone = customerPhone;
        this.saleID = runningID++;
        basket = new HashSet<OrderLine>();
    }
    
    public int getSaleID() {
        return saleID;
    }
    
    public int getEmployeeID() {
        return employeeID;
    }
    
    public String getCustomerPhone() {
        return customerPhone;
    }
    
    public boolean isPaid() {
        return paid;
    }
    
    /**
     * adds an orderline to the sale
     * 
     * @param quantity      the desired quantity
     * @param productID     the ID of the product
     */
    public boolean addOrderLine(int quantity, int productID) {
        OrderLine ol = new OrderLine(quantity, productID);
        basket.add(ol);
        return true;
    }
    
    /**
     * Removes an orderline from the sale
     * 
     * @param productID     the ID of the product
     */
    public boolean removeOrderLine(int productID) {
        Iterator<OrderLine> it = basket.iterator();
        OrderLine candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getProductID() == productID) {
                basket.remove(candidate);
            }
        }
        return true;
    }
    
    /**
     * Finds an orderline in a sale
     * 
     * @param productID     the ID of the product
     * @return o            the orderline found
     */
    public OrderLine findOrderLine(int productID) {
        Iterator<OrderLine> it = basket.iterator();
        OrderLine candidate = null;
        OrderLine o = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getProductID() == productID) {
                o = candidate;
            }   
        }
        return o;
    }
    
    /**
     * This method will calculate the total price of the sale
     * 
     * @return totalPrice       the price of the entire sale
     */
    public double totalPrice() {
        double totalPrice = 0;
        Iterator<OrderLine> it = basket.iterator();
        OrderLine candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            totalPrice += candidate.getSubTotal();
        }
        return totalPrice;
    }
    
    /**
     * Finalizes the sale. The paid boolean will be set to true
     */
    public boolean finalizeSale() {
        paid = true;
        Iterator<OrderLine> it = basket.iterator();
        OrderLine candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            int productID = candidate.getProductID();
            int quantity = candidate.getQuantity();
            Product p = proc.findProductByID(productID);
            p.decreaseStock(quantity);
        }
        return true;
    }
    
    /**
     * Gets the HashSet basket
     * 
     * @return basket   the HashSet
     */
    public HashSet<OrderLine> getBasket() {
        return basket;
    }
}
