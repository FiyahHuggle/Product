package ModelLayer;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SaleTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SaleTest
{
    private ModelLayer.Product product1;
    private ModelLayer.Product product2;
    private ModelLayer.Customer customer1;
    private ModelLayer.Employee employee1;
    private ModelLayer.Sale sale1;

    /**
     * Default constructor for test class SaleTest
     */
    public SaleTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        product1 = new ModelLayer.Product("Door" , 12, 12.30);
        product2 = new ModelLayer.Product("Table" , 13, 15.60);
        customer1 = new ModelLayer.Customer("Steve" , "123" , "12345" );
        employee1 = new ModelLayer.Employee("Bob" , "321" );
        sale1 = new ModelLayer.Sale(0, "12345" );
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
