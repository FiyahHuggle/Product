package TUILayer;


import CtrLayer.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class EmployeeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class EmployeeTest
{
    private TUILayer.PersonUI personUI1;
    private CtrLayer.PersonCtr personCt1;
    private CtrLayer.ProductCtr productCt1;
    

    /**
     * Default constructor for test class EmployeeTest
     */
    public EmployeeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        personUI1 = new TUILayer.PersonUI();
        personCt1 = new CtrLayer.PersonCtr();
        personCt1.createCustomer("Pien", "9000", "12345678");
        personCt1.createCustomer("Dora", "9001", "1");
        personCt1.createEmployee("Steven Teglman", "9000");
        productCt1 = new CtrLayer.ProductCtr();
        productCt1.createProduct("Box of chocolates", 25, 6);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
