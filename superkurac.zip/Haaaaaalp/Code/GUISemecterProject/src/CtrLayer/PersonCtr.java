package CtrLayer;
import ModelLayer.*;
import java.util.*;

/**
 * The controller for the Person Classes
 *
 * @author Steven Teglman
 * @version 14.12.2018
 */
public class PersonCtr {
    ProductContainer proc = ProductContainer.getInstance();
    PersonContainer perc = PersonContainer.getInstance();
    SaleContainer sc = SaleContainer.getInstance();
    
    /**
     * Creates a Person Controller Panel.
     */
    public PersonCtr() {
    }

    /**
     * Creates a new customer
     * 
     * @param name          The name of the customer
     * @param postalCode    The postal code of the customer
     * @param phone         The phone number of the customer
     * @return c            The new customer
     */
    public Customer createCustomer(String name, String postalCode, String phone) {
        Customer c = new Customer(name, postalCode, phone);
        perc.addPerson(c);
        return c;
    }

    /**
     * Creates a new employee
     * 
     * @param name          The name of the employee
     * @param postalCode    The postal code of the employee
     * @return e            The new employee
     */
    public Employee createEmployee(String name, String postalCode) {
        boolean result = false;
        Employee e = new Employee(name, postalCode);
        perc.addPerson(e);
        result = true;
        return e;
    }

    /**
     * Updates the customer's phone number
     * 
     * @param phone     The old phone number
     * @param newPhone  The new phone number
     */
    public boolean updatePhoneCustomer(String phone, String newPhone) {
        boolean result = false;
        findCustomer(phone).setPhone(newPhone);
        result = true;
        return result;
    }

    /**
     * Updates the customer's name
     * 
     * @param phone     The phone number
     * @param name      The new name
     */
    public boolean updateNameCustomer(String phone, String name) {
        boolean result = false;
        findCustomer(phone).setName(name);
        result = true;
        return result;
    }

    /**
     * Updates the customer's postal code
     * 
     * @param phone         The phone number
     * @param postalCode    The new postal code
     */
    public boolean updatePostalCodeCustomer(String phone, String postalCode) {
        boolean result = false;
        findCustomer(phone).setPostalCode(postalCode);
        result = true;
        return result;
    }

    /**
     * Updates the employee's name
     * 
     * @param employeeID    The ID
     * @param name          The new name
     */
    public boolean updateNameEmployee(int employeeID, String name) {
        boolean result = false;
        findEmployee(employeeID).setName(name);
        result = true;
        return result;
    }

    /**
     * Updates the employee's postal code
     * 
     * @param employeeID    The ID
     * @param postalCode    The new postal code
     */
    public boolean updatePostalCodeEmployee(int employeeID, String postalCode) {
        boolean result = false;
        findEmployee(employeeID).setPostalCode(postalCode);
        result = true;
        return result;
    }

    /**
     * Searches for a customer based on phone.
     * 
     * @param phone  The phone number of the customer
     * @return c     The customer found
     */
    public Customer findCustomer(String phone) {
        Customer c = perc.findCustomer(phone);
        return c; 
    }

    /**
     * Searches for a employee based on ID.
     * 
     * @param employeeID    The ID of the employee
     * @return e            The employee found
     */
    public Employee findEmployee(int employeeID) {
        Employee e = perc.findEmployee(employeeID);
        return e; 
    }

    /**
     * Removes a customer from people, which is the list of all people.
     * 
     * @param phone  the phone number of the customer who is removed
     */
    public boolean removeCustomer(String phone) {
        boolean result = false;
        perc.removePerson(findCustomer(phone));
        result = true;
        return result;
    }

    /**
     * Removes a employee from people, which is the list of all people.
     * 
     * @param employeeID  the ID of the employee who is removed
     */
    public boolean removeEmployee(int employeeID) {
        boolean result = false;
        perc.removePerson(findEmployee(employeeID));
        result = true;
        return result;
    }
    
    /**
     * Prints out the info of a customer by phone number
     * 
     * @param phone     The phone number of the customer
     */
    public void printCustomerInfo(String phone) {
        Customer c = findCustomer(phone);
        System.out.println("  ID :           "+c.getCustomerID());
        System.out.println("  Name :         "+c.getName());
        System.out.println("  Phone Number : "+c.getPhone());
        System.out.println("  Postal Code :  "+c.getPostalCode());
        System.out.println("|--------------------------------------|");
    }
    
    
    /**
     * Prints out the info of a employee by ID
     * 
     * @param employeeID    The ID of the employee
     */
    public void printEmployeeInfo(int employeeID) {
        Employee e = findEmployee(employeeID);
        System.out.println("  ID :          "+ e.getEmployeeID());
        System.out.println("  Name :        "+ e.getName());
        System.out.println("  Postal Code : "+e.getPostalCode());
        System.out.println("|--------------------------------------|");
    }
    
    /**
     * Prints out all the employees
     */
    public void printAllEmployees() {
        PersonContainer perc = PersonContainer.getInstance();
        HashSet<Employee> e = perc.getEmployees();
        Iterator<Employee> it = e.iterator();
        Employee candidate = null;
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<EMPLOYEE LIST>>            |");
        System.out.println("|--------------------------------------|");
        while (it.hasNext()) {
            candidate = it.next();
            System.out.println("  Name:        "+candidate.getName());
            System.out.println("  Postal Code: "+candidate.getPostalCode());
            System.out.println("  Employee #:  "+candidate.getEmployeeID());
            System.out.println("|--------------------------------------|");
        }
    }
    
    /**
     * Prints out all the customers
     */
    public void printAllCustomer() {
        PersonContainer perc = PersonContainer.getInstance();
        HashSet<Customer> c = perc.getCustomers();
        Iterator<Customer> it = c.iterator();
        Customer candidate = null;
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<CUSTOMER LIST>>            |");
    	System.out.println("|--------------------------------------|");
        while (it.hasNext()) {
            candidate = it.next();
            System.out.println("  Name:         "+candidate.getName());
            System.out.println("  Phone Number: "+candidate.getPhone());
            System.out.println("  Postal Code:  "+candidate.getPostalCode());
            System.out.println("  Customer ID #:"+candidate.getCustomerID());
            System.out.println("|--------------------------------------|");
        }
    }
    
    /**
     * Returns all employees
     * 
     * @return perc.getEmployees()    all the employees
     */
    public HashSet<Employee> getEmployees() {
        return perc.getEmployees();
    }
    
    /**
     * Returns all customers
     * 
     * @return perc.getCustomers()    all the customers
     */
    public HashSet<Customer> getCustomers() {
        return perc.getCustomers();
    }
    
    /**
     * Returns get a specific Employee Name
     * 
     * @return e.getName();    
     */   
    public String getEmployeeName(int ID) {
    	Employee e = findEmployee(ID);
    	return e.getName();
    }
}
