package ModelLayer;
import java.util.*;

/**
 * Container of all the Sales
 *
 * @author Pien van den Abeele
 * @version 14-12-2018
 */
public class SaleContainer {
    private HashSet<Sale> sales;
    public static SaleContainer instance;
    
    /**
     * Creates a list for all the sales
     */
    private SaleContainer() {
        sales = new HashSet();
    }
    
    public static SaleContainer getInstance() {
        if (instance == null) {
            instance = new SaleContainer();
        }
        return instance;
    }
    
    public int getEmployeeID(int saleID) {
        Iterator<Sale> it = sales.iterator();
        Sale candidate = null;
        Integer employeeID = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getSaleID() == saleID) {
                employeeID = candidate.getEmployeeID();
            }
        }
        return employeeID;
    }
    
    public String getCustomerPhone(int saleID) {
        Iterator<Sale> it = sales.iterator();
        Sale candidate = null;
        String phone = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getSaleID() == saleID) {
                phone = candidate.getCustomerPhone();
            }
        }
        return phone;
    }
    
    /**
     * Adds a sale to sales, which is the list of all sales.
     * 
     * @param sale  the sale which is added
     */
    public void addSale(Sale sale) {
        sales.add(sale);
    }
    
    /**
     * Reomves a sale from sales, which is the list of all sales.
     * @param sale  the sale which is removed
     */
    public void removeSale(Sale sale) {
        sales.remove(sale);
    }
    
    /**
     * Searches the HashSet sales for a sale based on ID.
     * 
     * @return returns either null or the specific product
     * @param saleID  the ID of the sale
     */
    public Sale findSale(int saleID) {
        Iterator<Sale> it = sales.iterator();
        Sale candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getSaleID() == saleID) {
                return candidate;
            }
        }
        return null;
    }
    
    /**
     * Returns all the sales stored in the HashSet sales
     * 
     * @return  returns the sales
     */
    public HashSet<Sale> getSales() {
        return sales;
    }
}
