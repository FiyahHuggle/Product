package ModelLayer;
import java.util.*;

/**
 * The superclass that handels all employees and customers
 *
 * @author Steven Teglman
 * @version 14.12.2018
 */
public class Person {
    public String name;
    public String postalCode;
    public boolean admin= false;
    
    /**
     * Creates a new person
     */
    public Person(String name, String postalCode) {
        this.name = name;
        this.postalCode = postalCode;
    }
    
    public String getName() {
        return name;
    }
    
    public String getPostalCode() {
        return postalCode;
    }
    
    public boolean isAdmin() {
        return admin;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    
    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
}
