package ModelLayer;
import java.util.*;

/**
 * The container for all of the Employees and Customers; The Persons
 *
 * @author Steven Teglman
 * @version 14-12-2018
 */
public class PersonContainer {
    private HashSet<Person> people;
    public static PersonContainer instance;

    public PersonContainer() {
        people = new HashSet();
    }

    public static PersonContainer getInstance() {
        if (instance == null) {
            instance = new PersonContainer();
        }
        return instance;
    }
    
    /**
     * Adds a person to people, which is the list of all people.
     * 
     * @param person  the person who is added
     */
    public void addPerson(Person person) {
        people.add(person);
    }

     /**
     * Removes a person from people, which is the list of all people.
     * 
     * @param person  the person who is removed
     */
    public void removePerson(Person person) {
        people.remove(person);
    }

    /**
     * Searches the HashSet people for a customer based on phone.
     * 
     * @return returns either null or the specific customer
     * @param phone  the phone number of the customer
     */
    public Customer findCustomer (String phone) {
        Iterator<Person> it = people.iterator();
        Person candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate instanceof Customer) {

                Customer p = (Customer)candidate ;

                if (p.getPhone().equals(phone)) {
                    return p;
                }
            }
        }
        return null;
    }

    /**
     * Searches the HashSet people for a employee based on ID.
     * 
     * @return returns either null or the specific employee
     * @param employeeID  the ID of the employee
     */
    public Employee findEmployee (int employeeID) {
        Iterator<Person> it = people.iterator();
        Person candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate instanceof Employee) {

                Employee p = (Employee)candidate ;

                if (p.getEmployeeID() == employeeID) {
                    return p;
                }
            }
        }
        return null;
    }
    
    /**
     * Returns all employees
     * 
     * @return emSet    all the employees
     */
    public HashSet<Employee> getEmployees() {
        Iterator<Person> it = people.iterator();
        HashSet<Employee> empSet = new HashSet();
        Person candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate instanceof Employee) {
                Employee p = (Employee)candidate;
                empSet.add(p);
            }
        }
        return empSet;    
    }
    
    /**
     * Returns all customers
     * 
     * @return cusSet    all the customers
     */
    public HashSet<Customer> getCustomers() {
        Iterator<Person> it = people.iterator();
        HashSet<Customer> cusSet = new HashSet();
        Person candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate instanceof Customer) {
                Customer p = (Customer)candidate;
                cusSet.add(p);
            }
        }
        return cusSet;    
    }
}
