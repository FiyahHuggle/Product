package ModelLayer;
import java.util.*;

/**
 * Container of all the Products
 *
 * @author Pien van den Abeele
 * @version 14-12-2018
 */
public class ProductContainer {
    private HashSet<Product> products;
    public static ProductContainer instance;
    
    /**
     * Creates a list for all the products 
     */
    private ProductContainer() {
        products = new HashSet();
    }  
    
    public static ProductContainer getInstance() {
        if (instance == null) {
            instance = new ProductContainer();
        }
        return instance;
    }
    
    /**
     * Adds a product to product, which is the list of all products.
     * 
     * @param product  the product which is added
     */
    public void addProduct(Product product) {
        products.add(product);
    }
    
    /**
     * Removes a product from products, which is the list of all products.
     * 
     * @param sale  the sale which is removed
     */
    public void removeProduct(Product product) {
        products.remove(product);
    }
    
    /**
     * Searches the HashSet products for a product based on ID.
     * 
     * @return returns either null or the specific product
     * @param productID  the ID of the product
     */
    public Product findProductByID(int productID) {
        Iterator<Product> it = products.iterator();
        Product candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getProductID() == productID) {
                return candidate;
            }
        }
        return null;
    }
    
    /**
     * Searches the HashSet products for a product based on name.
     * 
     * @return              returns either null or the specific product
     * @param productName     the name of the product
     */
    public Product findProductByName(String productName) {
        Iterator<Product> it = products.iterator();
        Product candidate = null;
        while (it.hasNext()) {
            candidate = it.next();
            if (candidate.getProductName().equals(productName)) {
                return candidate;
            }
        }
        return null;
    }
    
    /**
     * Returns all the products stored in the HashSet products
     * 
     * @return  returns the products
     */
    public HashSet<Product> getProducts() {
        return products;
    }
}
