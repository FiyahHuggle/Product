package ModelLayer;
import java.util.*;

/**
 * The Customer Class
 *
 * @author Steven Teglman
 * @version 14.12.2018
 */
public class Customer extends Person {
    private String phone;
    private static int runningID;
    private int customerID;

    /**
     * Creates a new Customer
     */
    public Customer(String name, String postalCode, String phone) {
        super(name, postalCode);
        this.phone = phone;
        admin = false;
        customerID = runningID++;
    }
    
    public Customer() {
        
        super("bob", "123");
    }
       
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String p) {
        phone = p;
    }
    
    public int getCustomerID () {
        return customerID;
    }
    
}
