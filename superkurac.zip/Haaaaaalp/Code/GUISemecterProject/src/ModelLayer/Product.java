package ModelLayer;
import java.util.*;

/**
 * Creating a Product
 *
 * @author Pien van den Abeele
 * @version 14-12-18
 */
public class Product {
    private String productName;
    private int productID;
    private int stock = 0;
    private static int runningID = 0;
    private double price;
    
    /**
     * Create a new Product
     * 
     * @param
     */
    public Product(String productName, int stock, double price) {
        this.productName = productName;
        if (stock >= 0) {
            this.stock = stock;
        }
        this.price = price;
        this.productID = runningID++;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public void setStock(int stock) {
        if (stock >= 0) {
            this.stock = stock;
        }
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public int getStock() {
        return stock;
    }
    
    public double getPrice() {
        return price;
    }
    
    public int getProductID() {
        return productID;
    }
    
     /**
      * When a sale is made, this method will decrease the stock
      */
    public void decreaseStock(int quantity) {
        stock -= quantity;
    }
    
    public void increaseStock(int quantity) {
    	stock += quantity;
    }
    
}
