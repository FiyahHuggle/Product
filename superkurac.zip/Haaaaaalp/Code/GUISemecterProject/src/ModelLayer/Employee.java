package ModelLayer;
import java.util.*;

/**
 * The Employee Class
 *
 * @author Steven Teglman
 * @version 14.12.2018
 */
public class Employee extends Person {
    private int employeeID;
    private static int runningID = 0;
    
    /**
     * Creates a new Employee
     */
    public Employee(String name, String postalCode) { 
        super(name, postalCode);
        admin = true;
        employeeID = runningID;
        runningID++;
    }
        
    public int getEmployeeID() {
        return employeeID;
    }
    
    public String getName() {
        return name;
    }
    
    public String getPostalCode() {
        return postalCode;
    }
    
}
