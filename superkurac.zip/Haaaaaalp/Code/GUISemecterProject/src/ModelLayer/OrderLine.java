package ModelLayer;
import java.text.DecimalFormat;
import java.util.*;

/**
 * Write a description of class OrderLine here.
 *
 * @author (your name)
 * @version 14-12-2018
 */
public class OrderLine {
    private int quantity;
    private int productID;
    private double subTotal;
	private DecimalFormat df2 = new DecimalFormat(".##");
    ProductContainer pc = ProductContainer.getInstance();
    
    /**
     * Creates a orderline
     */
    public OrderLine(int quantity, int productID) {
        this.productID = productID;
        this.quantity = quantity;
        calculateSubTotal();
    }
    
    public double getSubTotal() {
        return subTotal;
    }
    
    public int getProductID() {
        return productID;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int nQuantity) {
    	quantity = nQuantity;
    }
    
    /**
     * Calculates the sub total price of the orderline
     * 
     * @return subTotal     the subtotal of the orderline
     */
    public double calculateSubTotal() {
        Product p = pc.findProductByID(productID);
        double price = p.getPrice() * quantity;
        subTotal = price;
        return Double.parseDouble(df2.format(subTotal));
    }
}
