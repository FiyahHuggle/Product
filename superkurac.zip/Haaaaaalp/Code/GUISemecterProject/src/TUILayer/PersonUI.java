package TUILayer;
import CtrLayer.*;
import ModelLayer.*;
import java.util.*;

/**
 * UI for the Person classes.
 *
 * @author Steven Jack Teglman
 * @version 14.12.2018
 */
public class PersonUI
{
    private PersonCtr pctr = new PersonCtr();
    private Scanner in = new Scanner(System.in);

    /**
     * The User Interface for the Person Controller
     */
    public PersonUI() {
    }
    
    /**
     * For checking if the employee exists
     * 
     * @return employeeID       if the employee exists
     */
    private int checkEmployeeID() {
        Integer employeeID = null;
        do {
            if (employeeID != null) {
                System.out.println("There is no employee with this ID number. Please enter an existing ID.");
            }
            employeeID = enterNumber();
            if(employeeID == -1) {
                return -1;
            }
        } while (pctr.findEmployee(employeeID) == null);
        return employeeID;
    }

    /**
     * For checking if the customer exists
     * 
     * @return phone    if the customer exists
     */
    private String checkCustomerPhone() {
        String customerPhone = null;
        do {
            if (customerPhone != null && customerPhone.equals("back")) {
                return customerPhone;
            }
            if (customerPhone != null) {
                System.out.println("There is no customer with this number exists. Please enter an existing phone number.");
            }
            customerPhone = in.nextLine();
        } while (pctr.findCustomer(customerPhone) == null);
        return customerPhone;
    }

    /**
     * This is the input for navigating in the menu.
     * Makes sure the program won't crash in case of wrong input.
     * 
     * @return num returns the number put in
     */
    private int enterNumber() {
        while (!in.hasNextInt()) {
            if (in.next().equals("back")) {
                return -1;
            }
            System.out.println("Please enter a number.");
            in.nextLine();
        }
        int num = in.nextInt();
        in.nextLine();
        return num;
    }

    /**
     * The options for a user to do in the PersonUI.
     */
    public void personMainMenu() {
        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            printOptionsMainMenu();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                subMenuManageCustomer();
                break;
                case 2:
                subMenuManageEmployee();
                break;
                case 3:
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }
    }

    /**
     * The manage customer menu.
     */
    private void subMenuManageCustomer() {
        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            printOptionsManageCustomer();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                createNewCustomer();
                break;
                case 2:
                removeCustomer();
                break;
                case 3:
                if(pctr.getCustomers().size() != 0) {
                    subMenuUpdateCustomer();
                    break;
                }
                else {
                    System.out.println("\f#--------------------------------------#");
                    System.out.println("|      <<CUSTOMER MANAGEMENT MENU>>    |");
                    System.out.println("|--------------------------------------|");
                    System.out.println("  There are no customers in the database");
                    System.out.println("\n  Press any key to continue...");
                    String henrikIsAGreatTeacher = in.nextLine();
                    break;
                }
                case 4:
                customerList();
                break;
                case 5:
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }
    }

    /**
     * Prints out the options for manage customer menu
     */
    private void printOptionsManageCustomer() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CUSTOMER MANAGEMENT MENU>>    |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Create Customer                   |");
        System.out.println("| 2. Remove Customer                   |");
        System.out.println("| 3. Update Existing Customer          |");
        System.out.println("| 4. Customer List                     |");
        System.out.println("| 5. Return to Person Management Menu  |");
        System.out.println("#--------------------------------------#");

    }

    /**
     * To create a new customer
     * 
     * @return c    The new customer
     */
    public Customer createNewCustomer() {
        Customer c = null;
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW CUSTOMER>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Please Enter Customer Name:            ");
        String name = in.nextLine();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW CUSTOMER>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:          " + name);
        System.out.println("|--------------------------------------|");
        System.out.println("  Please Enter "+name+"'s Phone Number");
        String phoneNumber = in.nextLine();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW CUSTOMER>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:          " + name);
        System.out.println("  Phone Number:  " + phoneNumber);
        System.out.println("|--------------------------------------|");
        System.out.println("  Please Enter "+name+"'s Postal Code");
        String postalCode = in.nextLine();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW CUSTOMER>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:          " + name);
        System.out.println("  Phone Number:  " + phoneNumber);
        System.out.println("  Postal Code:   " + postalCode);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");

        boolean goingBack = false;
        int chosenOption = 0;
        String henrikIsAGreatTeacher = "";
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                c = pctr.createCustomer(name, postalCode, phoneNumber);
                System.out.println("\f#--------------------------------------#");
                System.out.println("|      <<CREATE NEW CUSTOMER>>         |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Name:          " + name);
                System.out.println("  Phone Number:  " + phoneNumber);
                System.out.println("  Postal Code:   " + postalCode);
                System.out.println("  Customer ID #: " + c.getCustomerID());
                System.out.println("|--------------------------------------|");
                System.out.println("  Customer Created!");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("  Customer not created.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }
        return c;
    }

    /**
     * Removes a customer from the system
     */
    private void removeCustomer() {
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<REMOVE CUSTOMER>>          |");
        System.out.println("|--------------------------------------|");
        pctr.printAllCustomer();
        System.out.println("  Please enter the phone number of");
        System.out.println("  \n  Type \"back\" to return to the\n  previous menu       ");
        String phone = checkCustomerPhone();
        if (phone.equals("back")) {
            return;
        }
        Customer c = pctr.findCustomer(phone);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<REMOVE CUSTOMER>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Phone Number: " + c.getPhone());
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this the customer you wish to remove?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        boolean goingBack = false;
        int chosenOption = 0;
        String henrikIsAGreatTeacher = "";
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|         <<REMOVE CUSTOMER>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Name:         " + c.getName());
                System.out.println("  Phone Number: " + c.getPhone());
                System.out.println("  Postal Code:  " + c.getPostalCode());
                System.out.println("  Customer ID#: " + c.getCustomerID());
                System.out.println("|--------------------------------------|");
                pctr.removeCustomer(phone);
                System.out.println("  Customer has been removed.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|         <<REMOVE CUSTOMER>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Name:         " + c.getName());
                System.out.println("  Phone Number: " + c.getPhone());
                System.out.println("  Postal Code:  " + c.getPostalCode());
                System.out.println("  Customer ID#: " + c.getCustomerID());
                System.out.println("|--------------------------------------|");
                System.out.println("  The customer has not been removed.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }
    }

    /**
     * The menu to update a customer
     */
    private void subMenuUpdateCustomer() {
        boolean goingBack = false;
        int chosenOption = 0;
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<CUSTOMER UPDATE MENU>>       |");
        System.out.println("#--------------------------------------#");
        pctr.printAllCustomer();
        System.out.println("  Please enter the phone number of the \n  customer you wish to update");
        System.out.println("  \n  Type \"back\" to return to the\n  previous menu       ");
        String phone = checkCustomerPhone();
        if (phone.equals("back")) {
            return;
        }
        while(!goingBack) {
            printOptionsUpdateCustomer(phone);
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                phone = updateCustomerName(phone);
                break;
                case 2:
                phone = updateCustomerPhoneNumber(phone);
                break;
                case 3:
                phone = updateCustomerPostalCode(phone);
                break;
                case 4:
                subMenuUpdateCustomer();
                goingBack = true;
                break;
                case 5:
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }

    }

    /**
     * Prints out the options for the update customer menu
     */
    private void printOptionsUpdateCustomer(String phone) {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<CUSTOMER UPDATE MENU>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Update Name                       |");
        System.out.println("| 2. Update Phone Number               |");
        System.out.println("| 3. Update Postal Code                |");
        System.out.println("| 4. Update Another Customer           |");
        System.out.println("| 5. Return to Customer Management Menu|");
        System.out.println("#--------------------------------------#");
        pctr.printCustomerInfo(phone);
    }

    /**
     * Method to update the customer's name
     * 
     * @param phone             The phone number of the customer
     * @return c.getPhone()     The phone number
     */
    private String updateCustomerName(String phone) {
        Customer c = pctr.findCustomer(phone);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<UPDATE CUSTOMER NAME>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Phone Number: " + phone);
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the updated name: ");
        String newName = in.nextLine();

        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<UPDATE CUSTOMER NAME>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + newName);
        System.out.println("  Phone Number: " + phone);
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        int chosenOption = 0;
        chosenOption = enterNumber();
        String henrikIsAGreatTeacher = "";
        switch (chosenOption) {
            case 1:
            pctr.updateNameCustomer(phone, newName);
            System.out.println("\f#--------------------------------------#");
            System.out.println("|       <<UPDATE CUSTOMER NAME>>       |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Phone Number: " + c.getPhone());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Customer ID#: " + c.getCustomerID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            case 2:
            System.out.println("\f#--------------------------------------#");
            System.out.println("|       <<UPDATE CUSTOMER NAME>>       |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Phone Number: " + c.getPhone());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Customer ID#: " + c.getCustomerID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has not been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            default:
            System.out.println("Invalid choice. Please try again");
        }
        return c.getPhone();
    }

    /**
     * Method to update the customer's phone number
     * 
     * @param phone          The old phone number
     * @return c.getPhone()  The phone number
     */
    private String updateCustomerPhoneNumber(String phone) {
        Customer c = pctr.findCustomer(phone);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|   <<UPDATE CUSTOMER PHONE NUMBER>>   |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Phone Number: " + phone);
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the updated phone number: ");
        String newPhone = in.nextLine();

        System.out.println("\f#--------------------------------------#");
        System.out.println("|   <<UPDATE CUSTOMER PHONE NUMBER>>   |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Phone Number: " + newPhone);
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        int chosenOption = 0;
        chosenOption = enterNumber();
        String henrikIsAGreatTeacher = "";
        switch (chosenOption) {
            case 1:
            pctr.updatePhoneCustomer(phone, newPhone);
            System.out.println("\f#--------------------------------------#");
            System.out.println("|   <<UPDATE CUSTOMER PHONE NUMBER>>   |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Phone Number: " + c.getPhone());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Customer ID#: " + c.getCustomerID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            case 2:
            System.out.println("\f#--------------------------------------#");
            System.out.println("|   <<UPDATE CUSTOMER PHONE NUMBER>>   |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Phone Number: " + c.getPhone());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Customer ID#: " + c.getCustomerID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has not been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            default:
            System.out.println("Invalid choice. Please try again");
        }
        return c.getPhone();
    }

    /**
     * Method to update the customer's postal code
     * 
     * @param phone          The phone number
     * @return c.getPhone()  The phone number
     */
    private String updateCustomerPostalCode(String phone) {
        Customer c = pctr.findCustomer(phone);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|    <<UPDATE CUSTOMER POSTAL CODE>>   |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Phone Number: " + phone);
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the updated postal code: ");
        String newPC = in.nextLine();

        System.out.println("\f#--------------------------------------#");
        System.out.println("|    <<UPDATE CUSTOMER POSTAL CODE>>   |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Phone Number: " + phone);
        System.out.println("  Postal Code:  " + newPC);
        System.out.println("  Customer ID#: " + c.getCustomerID());
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        int chosenOption = 0;
        chosenOption = enterNumber();
        String henrikIsAGreatTeacher = "";
        switch (chosenOption) {
            case 1:
            pctr.updatePostalCodeCustomer(phone, newPC);
            System.out.println("\f#--------------------------------------#");
            System.out.println("|    <<UPDATE CUSTOMER POSTAL CODE>>   |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Phone Number: " + c.getPhone());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Customer ID#: " + c.getCustomerID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            case 2:
            System.out.println("\f#--------------------------------------#");
            System.out.println("|    <<UPDATE CUSTOMER POSTAL CODE>>   |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Phone Number: " + c.getPhone());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Customer ID#: " + c.getCustomerID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has not been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            default:
            System.out.println("Invalid choice. Please try again");
        }
        return c.getPhone();
    }

    /**
     * Lists all the customers
     */
    private void customerList() {
        pctr.printAllCustomer();
        System.out.println("  Number of Customers on Record: "+ pctr.getCustomers().size());
        System.out.println("  Press any key to continue...");
        String henrikIsAGreatTeacher = in.nextLine();
    }

    /**
     * The manage employee menu
     */
    private void subMenuManageEmployee() {
        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            printOptionsManageEmployee();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                createNewEmployee();
                break;
                case 2:
                removeEmployee();
                break;
                case 3:
                subMenuUpdateEmployee();
                break;
                case 4:
                employeeList();
                break;
                case 5:
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }

    }

    /**
     * Creates a new employee
     */
    private void createNewEmployee() {
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW EMPLOYEE>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Please Enter Employee Name:            ");
        String name = in.nextLine();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW EMPLOYEE>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:        "+name);
        System.out.println("|--------------------------------------|");
        System.out.println("  Please Enter "+name+"'s Postal Code");
        String postalCode = in.nextLine();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW EMPLOYEE>>         |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:        "+name);
        System.out.println("  Postal Code: "+postalCode);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");

        boolean goingBack = false;
        int chosenOption = 0;
        String henrikIsAGreatTeacher = "";
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                Employee e = pctr.createEmployee(name, postalCode);
                System.out.println("\f#--------------------------------------#");
                System.out.println("|      <<CREATE NEW EMPLOYEE>>         |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Name:        " + name);
                System.out.println("  Postal Code: " + postalCode);
                System.out.println("  Employee #: " + e.getEmployeeID());
                System.out.println("|--------------------------------------|");
                System.out.println("  Employee Created!");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("  Employee not created.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }

    }

    /**
     * Removes a employee from the system
     */
    private void removeEmployee() {
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<REMOVE EMPLOYEE>>          |");
        System.out.println("|--------------------------------------|");
        pctr.printAllEmployees();
        System.out.println("  Please enter the ID of");
        System.out.println("  the employee being removed:    ");
        System.out.println("  \n  Type \"back\" to return to the\n  previous menu       ");
        int id = checkEmployeeID();
        if (id == -1) {
            return;
        }

        Employee e = pctr.findEmployee(id);

        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<REMOVE EMPLOYEE>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:        "+e.getName());
        System.out.println("  Postal Code: "+e.getPostalCode());
        System.out.println("  Employee #:  "+id);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this the employee you wish to remove?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        boolean goingBack = false;
        int chosenOption = 0;
        String henrikIsAGreatTeacher = "";
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|         <<REMOVE EMPLOYEE>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Name:        "+e.getName());
                System.out.println("  Postal Code: "+e.getPostalCode());
                System.out.println("  Employee #:  "+id);
                System.out.println("|--------------------------------------|");
                pctr.removeEmployee(id);
                System.out.println("  Employee has been removed.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|         <<REMOVE EMPLOYEE>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Name:        "+e.getName());
                System.out.println("  Postal Code: "+e.getPostalCode());
                System.out.println("  Employee #:  "+id);
                System.out.println("|--------------------------------------|");
                System.out.println("  Employee has been spared; you are a kind");
                System.out.println("  and benevolent God.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }
    }

    /**
     * Menu to update the employee
     */
    private void subMenuUpdateEmployee() {
        boolean goingBack = false;
        int chosenOption = 0;
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<EMPLOYEE UPDATE MENU>>       |");
        System.out.println("#--------------------------------------#");
        pctr.printAllEmployees();
        System.out.println("  Please enter the employee ID of the \n  employee you wish to update");
        System.out.println("  \n  Otherwise type \"back\" to return to the\n  previous menu       ");
        int ID = checkEmployeeID();
        if (ID == -1) {
            return;
        }
        while(!goingBack) {
            printOptionsUpdateEmployee(ID);
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                ID = updateEmployeeName(ID);
                break;
                case 2:
                ID = updateEmployeePostalCode(ID);
                break;
                case 3:
                subMenuUpdateEmployee();
                goingBack = true;
                break;
                case 4:
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
            }
        }
    }

    /**
     * Prints out options for the update employee menu
     * 
     * @param ID    The employee ID
     */
    private void printOptionsUpdateEmployee(int ID) {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<EMPLOYEE UPDATE MENU>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Update Name                       |");
        System.out.println("| 2. Update Postal Code                |");
        System.out.println("| 3. Update Another Employee           |");
        System.out.println("| 4. Return to Employee Management Menu|");
        System.out.println("#--------------------------------------#");
        pctr.printEmployeeInfo(ID);
    }

    /**
     * Updates the employee's name
     * 
     * @param ID                    The employee ID
     * @return c.getEmployeeID()    the employee ID
     */
    private int updateEmployeeName(int ID) {
        Employee c = pctr.findEmployee(ID);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<UPDATE EMPLOYEE NAME>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Employee #:   " + ID);
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the updated name: ");
        String newName = in.nextLine();

        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<UPDATE EMPLOYEE NAME>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + newName);
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Employee #:   " + ID);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        int chosenOption = 0;
        chosenOption = enterNumber();
        String henrikIsAGreatTeacher = "";
        switch (chosenOption) {
            case 1:
            pctr.updateNameEmployee(ID, newName);
            System.out.println("\f#--------------------------------------#");
            System.out.println("|       <<UPDATE CUSTOMER NAME>>       |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Employee #:   " + c.getEmployeeID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            case 2:
            System.out.println("\f#--------------------------------------#");
            System.out.println("|       <<UPDATE CUSTOMER NAME>>       |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Employee #:   " + c.getEmployeeID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has not been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            default:
            System.out.println("Invalid choice. Please try again");
        }
        return c.getEmployeeID();
    }

    /**
     * Updates the employee's postal code
     * 
     * @param ID                    The employee ID
     * @return c.getEmployeeID()    the employee ID
     */
    private int updateEmployeePostalCode(int ID) {
        Employee c = pctr.findEmployee(ID);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|    <<UPDATE EMPLOYEE POSTAL CODE>>   |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Postal Code:  " + c.getPostalCode());
        System.out.println("  Employee #:   " + ID);
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the updated postal code: ");
        String newPC = in.nextLine();

        System.out.println("\f#--------------------------------------#");
        System.out.println("|    <<UPDATE EMPLOYEE POSTAL CODE>>   |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Name:         " + c.getName());
        System.out.println("  Postal Code:  " + newPC);
        System.out.println("  Employee #:   " + ID);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");
        int chosenOption = 0;
        chosenOption = enterNumber();
        String henrikIsAGreatTeacher = "";
        switch (chosenOption) {
            case 1:
            pctr.updatePostalCodeEmployee(ID, newPC);
            System.out.println("\f#--------------------------------------#");
            System.out.println("|    <<UPDATE EMPLOYEE POSTAL CODE>>   |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Employee #:   " + c.getEmployeeID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            case 2:
            System.out.println("\f#--------------------------------------#");
            System.out.println("|    <<UPDATE EMPLOYEE POSTAL CODE>>   |");
            System.out.println("|--------------------------------------|");
            System.out.println("  Name:         " + c.getName());
            System.out.println("  Postal Code:  " + c.getPostalCode());
            System.out.println("  Employee #:   " + c.getEmployeeID());
            System.out.println("|--------------------------------------|");
            System.out.println("  Information has not been updated.");
            System.out.println("  Press any key to continue...");
            henrikIsAGreatTeacher = in.nextLine();
            break;

            default:
            System.out.println("Invalid choice. Please try again");
        }
        return c.getEmployeeID();
    }

    /**
     * Prints out all the employees
     */
    private void employeeList() {
        pctr.printAllEmployees();
        System.out.println("  Number of Employees: "+ pctr.getEmployees().size());
        System.out.println("  Press any key to continue...");
        String henrikIsAGreatTeacher = in.nextLine();
    }

    /**
     * Prints out the options for the main menu
     */
    private void printOptionsMainMenu() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<PERSON MANAGEMENT MENU>>      |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Customer Management               |");
        System.out.println("| 2. Employee Management               |");
        System.out.println("| 3. Return to Main Menu               |");
        System.out.println("#--------------------------------------#");

    }

    /**
     * Print out the options for manage employee menu
     */
    private void printOptionsManageEmployee() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<EMPLOYEE MANAGEMENT MENU>>    |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Create Employee                   |");
        System.out.println("| 2. Remove Employee                   |");
        System.out.println("| 3. Update Existing Employee          |");
        System.out.println("| 4. Employee List                     |");
        System.out.println("| 5. Return to Person Management Menu  |");
        System.out.println("#--------------------------------------#");

    }
}