package TUILayer;

import CtrLayer.*;
import ModelLayer.*;
import java.util.*;

/**
 * Product UI
 *
 * @author Dora Grgurev
 * @version 14.12.2018
 */
public class ProductUI {
    private ProductCtr productCtr = new ProductCtr();
    private Scanner in = new Scanner(System.in);
    private static int runningID;

    /**
     * The User Interface for the Product Controller
     */
    public ProductUI() {
    }

    /** 
     * Method for checking if there are any products in store.
     * 
     * @return true if there are products in store.
     * @return false if there are no products in store.
     */
    private boolean checkProductList() {
        if (productCtr.getAllProducts().isEmpty()){
            System.out.println("There are no products in store.");
            return false;
        } else {
            return true;
        }
    }

    /**
     * Method for checking if the product name is an existing one.
     * 
     * @return theProductName returns the product's name.
     **/
    private String checkProductName(){
        String theProductName = null;
        do {
            if (theProductName != null) {
                System.out.println("This product name doesn't exist. Please enter an existing one.");
            }
            theProductName = enterText();
        } while (productCtr.findProductByName(theProductName) == null);
        return theProductName;
    }

    /**
     * Method for entering a product ID to check if it is an existing one.
     * 
     * @return theProductID returns the product's ID.
     **/
    private Integer checkProductID(){
        Integer theProductID = null;
        do {
            if (theProductID != null) {
                System.out.println("This product ID doesn't exist. Please enter an existing one.");
            }
            theProductID = enterNumber();
        } while (productCtr.findProductByID(theProductID) == null);
        return theProductID;
    }

    /**
     * Prints out the Main Menu options.
     */
    private void printOptionsMainMenu() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<PRODUCT MANAGEMENT MENU>>     |");        
        System.out.println("|--------------------------------------|");
        System.out.println("| 1. Create a product                  |");        
        System.out.println("| 2. Remove a product                  |");   
        System.out.println("| 3. Update product                    |");
        System.out.println("| 4. List products                     |");
        System.out.println("| 5. Return to Main Menu               |");
        System.out.println("#--------------------------------------#");
    }

    /**
     * The choices which the user can choose in the Product Main Menu options.
     */
    public void productMainMenu() {
        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            printOptionsMainMenu();
            chosenOption = enterNumber();
            if ((chosenOption==1 || chosenOption==5) || checkProductList()) {
                switch (chosenOption) {
                    case 1:
                    createProduct();
                    break;
                    case 2:
                    removeProduct();
                    break;
                    case 3:
                    subMenuUpdateProduct();
                    break;
                    case 4:
                    printProductList();
                    System.out.println("  Press any key to continue...");
                    String carryOn = in.nextLine();
                    break;
                    case 5:
                    System.out.println("You can't go back from here.");
                    goingBack = true;
                    break;
                    default:
                    System.out.println("Invalid command. Please try again.");
                }
            }
        }
    }

    /**
     * Method for printing the Update product menu options.
     */
    private void printOptionsUpdateProduct() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<UPDATE PRODUCT MENU>>        |");        
        System.out.println("|--------------------------------------|");
        System.out.println("| 1. Update product name               |");        
        System.out.println("| 2. Update product stock              |");
        System.out.println("| 3. Update product price              |");
        System.out.println("| 4. Return to Product management menu |");
        System.out.println("#--------------------------------------#");
    }

    /**
     * Method for updating a product.
     * Method for returning the sub menu Update product options.
     */
    public void subMenuUpdateProduct() {
        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            printOptionsUpdateProduct();
            chosenOption = enterNumber();
            if ((chosenOption==1 || chosenOption==3) || checkProductList()) {
                switch (chosenOption) {
                    case 1:
                    updateProductName();
                    break;
                    case 2:
                    updateStock();
                    break;
                    case 3:
                    updatePrice();
                    break;
                    case 4:
                    goingBack = true;
                    default:
                    System.out.println("Invalid command. Please try again.");                    
                }
            }
        }
    }

    /**
     * Method for creating a product
     */
    private void createProduct(){
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW PRODUCT>>          |");
        System.out.println("|--------------------------------------|");

        System.out.println("  Please enter a product name:          ");        
        String productName = in.nextLine();

        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW PRODUCT>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Product name:          " + productName);
        System.out.println("|--------------------------------------|");

        System.out.println("  Please enter the product stock");
        int stock = enterNumber();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW PRODUCT>>          |");
        System.out.println("|--------------------------------------|"); 
        System.out.println("  Product name:         " + productName);
        System.out.println("  Product stock:        " + stock);
        System.out.println("|--------------------------------------|");

        System.out.println("  Please enter the product price");
        double price = enterDouble();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW PRODUCT>>          |");
        System.out.println("|--------------------------------------|"); 
        System.out.println("  Product name:         " + productName);
        System.out.println("  Product stock:        " + stock);
        System.out.println("  Product price:        $" + price);
        System.out.println("|--------------------------------------|");

        System.out.println("\f#--------------------------------------#");
        System.out.println("|      <<CREATE NEW PRODUCT>>          |");
        System.out.println("|--------------------------------------|"); 
        System.out.println("  Product name:         " + productName);
        System.out.println("  Product stock:        " + stock);
        System.out.println("  Product price:        $" + price);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");        

        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                Product p = productCtr.createProduct(productName, stock, price);
                System.out.println("\f#--------------------------------------#");
                System.out.println("|      <<CREATE NEW PRODUCT>>          |");
                System.out.println("|--------------------------------------|"); 
                System.out.println("  Product name:         " + productName);
                System.out.println("  Product stock:        " + stock);
                System.out.println("  Product price:        $" + price);
                System.out.println("  Product ID:           " + p.getProductID());
                System.out.println("|--------------------------------------|");

                if(stock > 1){
                    System.out.println("The products " + productName + "s (ID: " + p.getProductID() + ") have been created. There are currently " + stock + " " + productName + "s in stock. The price is $" + price + "/piece.");
                } else {
                    System.out.println("The product " + productName + " (ID: " + p.getProductID() + ") has been created. There is currently " + stock + " " + productName + " in stock. The price is $" + price + "/piece.");
                }                                
                System.out.println("  Press Enter to continue...");
                String carryOn = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("  Product not created.");
                System.out.println("  Press Enter to continue...");
                carryOn = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("  Invalid choice. Please try again");
            }
        }        
    }

    /**
     * Method for deleting a product.
     */
    private void removeProduct(){
        printProductList();
        System.out.println("  Please enter a product ID of the product you want to remove");
        int productID = checkProductID();
        Product p = productCtr.findProductByID(productID);

        if (p == null) {
            System.out.println("  There are no products with this ID. Please try again.");
        } else {            
            productCtr.removeProduct(productID);
        }        
        System.out.println("\f  The product with ID: " + p.getProductID() + " has been removed. Insert any text to continue...");
        in.nextLine();
    }
    
    /**
     * Method for updating a product's name.
     */
    private void updateProductName(){
        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<UPDATE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");

        printProductList();
        System.out.println("  Please enter the product ID:          ");
        int productID = checkProductID();         

        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<CHOOSE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Product ID:          " + productID     );
        System.out.println("|--------------------------------------|");

        System.out.println("  Please enter an updated product name:  ");
        String productName = in.nextLine();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<UPDATE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");    
        System.out.println("  Product ID:        " + productID       );
        System.out.println("  Product name:      " + productName     );       
        System.out.println("|--------------------------------------|");  
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");        

        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|          <<UPDATE PRODUCT>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Product ID:        " + productID       );
                System.out.println("  New product name:  " + productName     );
                System.out.println("|--------------------------------------|");

                productCtr.updateProductName(productID, productName);

                System.out.println("  The product has been updated, it is now named " + productName + ".");
                System.out.println("  Press Enter to continue...");
                String carryOn = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("  Product not updated.");
                System.out.println("  Press Enter to go back and retry.");
                in.next();
                goingBack = true;
                break;
                default:                
                System.out.println("  Invalid choice. Please try again"); 
                goingBack = false;
                break;
            }
        }
    }

    /**
     * Method for updating the stock value of a product.
     */
    private void updateStock(){         
        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<UPDATE PRODUCT>>          |");

        printProductList();
        System.out.println("  Please enter the product ID:          ");
        int productID = checkProductID();   

        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<CHOOSE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Product ID:        " + productID       );
        System.out.println("|--------------------------------------|");

        System.out.println("  Please enter a new stock value:       ");
        int stock = enterNumber();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<UPDATE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");        
        System.out.println("  Product ID:        " + productID       );
        System.out.println("  New stock value:   " + stock           ); 
        System.out.println("|--------------------------------------|");  
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");        

        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:                
                System.out.println("\f#--------------------------------------#");
                System.out.println("|          <<UPDATE PRODUCT>>          |");
                System.out.println("|--------------------------------------|");        
                System.out.println("  Product ID:        " + productID       );
                System.out.println("  New stock value:   " + stock           ); 
                System.out.println("|--------------------------------------|");  

                productCtr.updateStock(productID, stock);

                System.out.println("  The product has been updated, its stock value is now " + stock + ".");
                System.out.println("  Press Enter to continue...");
                String carryOn = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("  Product not updated.");
                System.out.println("  Enter any input to go back and retry.");
                in.next();
                goingBack = true;
                break;
                default:
                System.out.println("  Invalid choice. Please try again");
                goingBack = false;
                break; 
            }
        }
    }

    /**
     * Method for updating the price of a product.
     */
    private void updatePrice(){        
        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<UPDATE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");

        printProductList();
        System.out.println("  Please enter the product ID:          ");
        int productID = checkProductID();   

        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<CHOOSE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Product ID:         " + productID      );
        System.out.println("|--------------------------------------|");

        System.out.println("  Please enter a new price:             ");
        double price = enterDouble();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<UPDATE PRODUCT>>          |");
        System.out.println("|--------------------------------------|");        
        System.out.println("  Product ID:         " + productID      );
        System.out.println("  New price:          $" + price          ); 
        System.out.println("|--------------------------------------|");  
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");        

        boolean goingBack = false;
        int chosenOption = 0;
        while(!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:                
                System.out.println("\f#--------------------------------------#");
                System.out.println("|          <<UPDATE PRODUCT>>          |");
                System.out.println("|--------------------------------------|");        
                System.out.println("  Product ID:          " + productID     );
                System.out.println("  New price:           $" + price         ); 
                System.out.println("|--------------------------------------|");  

                productCtr.updatePrice(productID, price);

                System.out.println("  The product has been updated, its new price is now $" + price + ".");
                System.out.println("  Press Enter to continue...");
                String carryOn = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("  Product not updated.");
                System.out.println("  Enter any input to go back and retry.");
                in.next();
                goingBack = true;
                break;
                default:
                System.out.println("  Invalid choice. Please try again");
                goingBack = false;
                break; 
            }
        }
    }

    /**
     * Method to print out a List of products.
     */
    private void printProductList() {
        if (checkProductList() == false){
            System.out.println("\f  There are no products in store.");
        } else {
            System.out.println("\f");
            productCtr.printAllProducts();            
        } 
    } 

    /** 
     * This is the input for navigating in the menu.
     *  It makes sure the program won't crash in case of wrongly input stock value.
     * 
     * @return num returns the input number
     **/
    private int enterNumber() {
        while (!in.hasNextInt()) {
            System.out.println("  Please enter a number to choose an option.");
            in.nextLine();
        }
        int num = in.nextInt();
        in.nextLine();
        return num;
    }

    /**
     * This is the input for navigating in the menu.
     *  It makes sure the program won't crash in case of wrongly input price.
     *  
     *  @return num returns the input number
     */
    private double enterDouble() {
        while (!in.hasNextDouble()) {
            System.out.println("  Please enter a number to choose an option.");
            in.nextLine();
        }
        double num = in.nextDouble();
        in.nextLine();
        return num;
    }

    /** This is the input for navigating in the menu.
     *  It makes sure the program won't crash in case of wrongly input product name.
     *  
     *  @return line
     */
    private String enterText() {
        while (!in.hasNextLine()) {
            System.out.println("  Please enter a number to choose an option.");
            in.nextLine();
        }
        String text = in.nextLine();
        in.nextLine();
        return text;
    }
}