package TUILayer;

import java.util.*;

/**
 * Write a description of class MainMenuUI here.
 *
 * @author Steven Jack Teglman, Pien van den Abeele
 * @version 14-12-2018
 */
public class MainMenuUI
{
    private static Scanner in = new Scanner(System.in);
    private PersonUI personUI = new PersonUI();
    private SaleUI saleUI = new SaleUI();
    private ProductUI productUI = new ProductUI();
    
    public static void main(String[] args)
    {
    	MainMenuUI MUI = new MainMenuUI();
        printPug();
        String s = "\nDPS Studios (TM) is a partnership consisting of: \n";
        slowPrint(s, 20);
        s = "#Dora Grgurev\n";
        slowPrint(s, 20);
        s = "#Pien van den Abeele \n";
        slowPrint(s, 20);
        s = "#Steven Jack Teglman\n";
        slowPrint(s, 20);
        s = "\nPress any key to continue...";
        slowPrint(s, 20);
        String whatIsLove = in.nextLine();
        MUI.mainMenu();
    }

    private static void printOptionsMainMenu() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|             <<MAIN MENU>>            |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Sale Manager                      |");
        System.out.println("| 2. Product Manager                   |");
        System.out.println("| 3. Person Manager                    |");
        System.out.println("| 4. Exit                              |");
        System.out.println("#--------------------------------------#");

    }

    private void mainMenu() {
        boolean Exit = false;
        int chosenOption = 0;
        while (!Exit) {
            printOptionsMainMenu();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                saleUI.saleMainMenu();
                break;
                case 2:
                productUI.productMainMenu();
                break;
                case 3: 
                personUI.personMainMenu();
                break;
                case 4:
                Exit=true;
                System.out.println("Goodbye");
                break;
                default:
                System.out.println("Unvalid command. Try again.");
            }
        }
    }
    
    private static int enterNumber() {
        while (!in.hasNextInt()) {
           System.out.println("Please enter a number.");
           in.nextLine();
        }
        int num = in.nextInt();
        in.nextLine();              //Consume newline left-over 
        return num;
    }
    
    private static void slowPrint(String message, long millisPerChar)
    {
        for (int i = 0; i < message.length(); i++)
        {
            System.out.print(message.charAt(i));

            try
            {
                Thread.sleep(millisPerChar);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
    }

    private static void printPug() {
        System.out.println("\f");
        System.out.println("                                  .,/*  /(*.*(*((*.     .,.                                     ");
        System.out.println("                         ./%%/#/,..   .    *        ./#@@%#@@&%,                                ");
        System.out.println("                     .(&@@@@@#   /             ,         %@/@@@@@*                              ");
        System.out.println("                .(%@@@@@@@@&,   ,    (   *  *  .(.       .&(#@@@@@@@&@@@#.                      ");
        System.out.println("              #@@@@@@@&@&,               /  /.     .      .@#(@@@@@@@@@@@%                      ");
        System.out.println("             (@@@@@@@%&&,        ..          ,  .,,,*/     ,&@&((@@@@@@@@/                      ");
        System.out.println("             *@@@@@@@/@#       ,      *.  ,.  *       .**.    /&@(#@@@@@%                       ");
        System.out.println("              /@@@@@@/@(    ,     *%&&,,  ,*    (@@@%     .,    %@@@@@                          ");
        System.out.println("               #@@@@@/@/ */.&@@@@&@@@@((  .(  , (@@@@@@@@%,./   %#@&&@&,                        ");
        System.out.println("                ,&@@@*,,/@&&@&(%/@@%#/##(((#%(%@@((&&&@*/   %.%@@@,                             ");
        System.out.println("                  (@@@@,..(@/#@@@@(&@&/,,,*(&@#(%@@@&/@..   /,                                  ");
        System.out.println("                   ,%@&.   /@&&@@&&&/&%&%@#&%#&&(#@&&%.  ./. %                                  ");
        System.out.println("                      %.** .,/#&@@%&@@#*&@#&/%/@@@#&&&@@&(   .*%*                               ");
        System.out.println("                      #*, (@@@@@@@@@@@@@&%/(%@@@@@@@@@@@@&@@%   .((                             ");
        System.out.println("                     .( . #@.,%@@%&&@@&%@@*%@@%@@&&@@#,/%@%    &.                               ");
        System.out.println("                      &,  .%&@%*&@%&@@@&*/&%*(&@@@%@@(*&@@@%    %%                              ");
        System.out.println("                      /@*   &@@@%*,,,,*%@@@@@@&*****##&@@@%   *&,&*                             ");
        System.out.println("                      %,.#/  ,&@@@((&@*   /,   ,@%(,%@@@#  .##  /,*(                            ");
        System.out.println("                     *&*   ,   .%@@@&&*   ,    ,&@@@@&/   *.   #( ,(                            ");
        System.out.println("                    .%,&.         *%@@@&/.   ./@@@&(.        #%.  /#/                           ");
        System.out.println("                    .% .&*     ,*       */###(*.          .%,       /#                          ");
        System.out.println("                     %   (#      /.                      #/     .    &,                         ");
        System.out.println("                     #    .%.     ./,   ,//*,*(/.      *(      ,/    ((                         ");
        System.out.println("                    */ *    .#/      .          *#(.  ,,             *%                         ");
        System.out.println("                    (/ ./     .#              /.                     *%                         ");
        System.out.println("                    #*   **    .#.      ./.                          (#                         ");
        System.out.println("                    %*           ./        /               (.        %%                         ");
        System.out.println("                    %*                                  ,/*         ,&(*                        ");
        System.out.println("                    (/                                              (# #                        ");
        System.out.println("                    *%                                             .&, *.                       ");
        System.out.println("                    ,%,           .,*///*     ,/*,.                *&  ./                       ");
        System.out.println("                    ,&.                                */.         .&/.,(&,                     ");
        System.out.println("                    ,%       /*                          (*         ,&,   ((                    ");
        System.out.println("                    *%      //,                          .%         /%     %*                   ");
        System.out.println("                    *%      %,,                           ,/        #/     *%                   ");
        System.out.println("                    ,%      % ..                           %*       &,     .&,                  ");
        System.out.println("                    ,%      #%(                            /%      ,&.      %*                  ");
        System.out.println("                    ,%      .%,%*                          %*      /%       &,                  ");
        System.out.println("                    *#      .%. /#                         %       #(      /%                   ");
        System.out.println("                   ,%.      %***. %,                      ./       %*     %(                    ");
        System.out.println("                ,(#,       **      ,&(                   .#,       &,   (&/                     ");
        System.out.println("              /#,         .&/ ((.  /( ,#(,           *#%/.#       ,%%(.  .,#.                   ");
        System.out.println("             /*#*   *(   .&(#*###%*          ..,,..       %       .,*%%.  .#, (.                ");
        System.out.println("             ,#%,   %. .#%.                               /,    ,. .# *%(.  *%#.                ");
        System.out.println("               *(%%%*(#*                                   &((   ( .%#%*.***,                   ");
        System.out.println("                                                             ,((/.,.                            ");
        System.out.println("                                                                                                ");
        System.out.println("                 ____________  _____   _____ _             _ _                                  ");
        System.out.println("                 |  _  \\ ___ \\/  ___| /  ___| |           | (_)                               ");
        System.out.println("                 | | | | |_/ /\\ `--.  \\ `--.| |_ _   _  __| |_  ___  ___                      ");
        System.out.println("                 | | | |  __/  `--. \\  `--. \\ __| | | |/ _` | |/ _ \\/ __|                    ");
        System.out.println("                 | |/ /| |    /\\__/ / /\\__/ / |_| |_| | (_| | | (_) \\__ \\                   ");
        System.out.println("                 |___/ \\_|    \\____/  \\____/ \\__|\\__,_|\\__,_|_|\\___/|___/                ");

    }
}