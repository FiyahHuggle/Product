package TUILayer;

import CtrLayer.*;
import ModelLayer.*;
import java.util.*;

/**
 * UI for the sale class.
 *
 * @author Pien van den Abeele
 * @version 14-12-2018
 */
public class SaleUI {
    private Scanner in = new Scanner(System.in);
    private SaleCtr saleCtr = new SaleCtr();
    private PersonCtr personCtr = new PersonCtr();
    private ProductCtr productCtr = new ProductCtr();

    /**
     * The User Interface for the Sale Controller
     */
    public SaleUI() {
    }

    /**
     * Prints out the MainMenu options.
     */
    private void printOptionsMainMenu() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|       <<SALE MANAGEMENT MENU>>       |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Start a sale                      |");
        System.out.println("| 2. Manage Sale                       |");
        System.out.println("| 3. Sale Lists                        |");
        System.out.println("| 4. Sale Info                         |");
        System.out.println("| 5. Remove a Sale                     |");
        System.out.println("| 6. Return to Main Menu               |");
        System.out.println("#--------------------------------------#");
    }

    /**
     * Prints out the Sale List Menu options.
     */
    private void printOptionsSaleListsMenu() {
        System.out.println();
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<SALE LISTS MENU>>          |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. List of all sales                 |");
        System.out.println("| 2. List of a employee sales          |");
        System.out.println("| 3. List of a customer sales          |");
        System.out.println("| 4. Return to Main Menu               |");
        System.out.println("#--------------------------------------#");
    }

    /**
     * Prints out the Start Sale Menu options.
     */
    private void printOptionsStartSaleMenu() {
        System.out.println();
        System.out.println("#--------------------------------------#");
        System.out.println("|            <<SALE MENU>>             |");
        System.out.println("|--------------------------------------|");
        System.out.println("| Options                              |");
        System.out.println("| 1. Add Product                       |");
        System.out.println("| 2. Finalize Sale                     |");
        System.out.println("| 3. Remove Product from Sale          |");
        System.out.println("| 4. Return to Sale Management Menu               |");
        System.out.println("#--------------------------------------#");
    }

    /**
     * The options for a user to do in the SaleUI.
     */
    public void saleMainMenu() {
        boolean goingBack = false;
        int chosenOption = 0;
        while (!goingBack) {
            printOptionsMainMenu();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                if ((personCtr.getEmployees().size() == 0) || (productCtr.getAllProducts().size() ==0)) {
                    if (personCtr.getEmployees().size() == 0) {
                        System.out.println("\f  There are no employees yet. Please go to Person Management.");
                    }
                    else {
                        System.out.println("\f  There are no products yet. Please go to Product Management.");
                    }
                    System.out.print("  Press any key to return back to the Sale Menu.");
                    String hoi = in.nextLine();
                }
                else {
                    subMenuCreateSale();
                }
                break;
                case 2:
                if (checkSaleList() == false) {
                    System.out.println("\f  There are no sales yet.");
                    System.out.print("  Press any key to return back to the Sale Menu.");
                    String hoi = in.nextLine();
                }
                else {
                    manageSale();
                }
                break;
                case 3:
                if (checkSaleList() == false) {
                    System.out.println("\f  There are no sales yet.");
                    System.out.print("  Press any key to return back to the Sale Menu.");
                    String hoi = in.nextLine();
                }
                else {
                    subMenuSaleLists();
                }
                break;
                case 4:
                if (checkSaleList() == false) {
                    System.out.println("\f  There are no sales yet.");
                    System.out.print("  Press any key to return back to the Sale Menu.");
                    String hoi = in.nextLine();
                }
                else {
                    saleInfoByID();
                }
                break;
                case 5:
                if (checkSaleList() == false) {
                    System.out.println("\f  There are no sales yet.");
                    System.out.print("  Press any key to return back to the Sale Menu.");
                    String hoi = in.nextLine();
                }
                else {
                    removeSale();
                }
                break;
                case 6:
                goingBack = true;
                break;
                default:
                System.out.println("Invalid command. Try again.");
                break;
            }
        }
    }

    /**
     * The create a sale menu
     */
    private void subMenuCreateSale() {
        System.out.println("\f#--------------------------------------#");
        System.out.println("|        <<CREATE NEW SALE>>           |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Please Enter Employee ID:            ");
        int employeeID = enterNumber();
        employeeID = checkEmployeeIDForSale(employeeID);

        boolean goingBack = false;
        int chosenOption1 = 0;
        if (employeeID == -1) {
            while (!goingBack) {
                chosenOption1 = enterNumber();;
                switch (chosenOption1) {
                    case 1:
                    System.out.println("\f#--------------------------------------#");
                    System.out.println("|        <<CREATE NEW SALE>>           |");
                    System.out.println("|--------------------------------------|");
                    System.out.println("|  Please Enter Employee ID:           |");
                    employeeID = enterNumber();
                    employeeID = checkEmployeeIDForSale(employeeID);
                    if (employeeID != -1) {
                        goingBack = true;
                    }
                    break;
                    case 2:
                    goingBack = true;
                    return;
                    default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
                }
            }
        } 
        System.out.println("\f#--------------------------------------#");
        System.out.println("|        <<CREATE NEW SALE>>           |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Employee:        "+ employeeID);
        System.out.println("|--------------------------------------|");
        System.out.println("|  Customer:                           |");
        System.out.println("|  1. Enter customer phone number.     |");
        System.out.println("|  2. Create a new customer            |");
        System.out.println("|--------------------------------------|");

        String phone = null;
        boolean goingBack1 = false;
        int chosenOption2 = 0;
        while (!goingBack1) {
            chosenOption2 = enterNumber();
            switch (chosenOption2) {
                case 1:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|        <<CREATE NEW SALE>>           |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Employee:        "+ employeeID);
                System.out.println("|--------------------------------------|");
                System.out.println("  Please Enter Customer Phone Number:");
                phone = checkPhoneForSale();
                if (phone != null) {
                    goingBack1 = true;
                }
                break;
                case 2:
                PersonUI personUI = new PersonUI();
                Customer c = personUI.createNewCustomer();
                phone = c.getPhone();
                goingBack1 = true;
                break;
                case 3:
                goingBack1 = true;
                return;
                default:
                System.out.println("Invalid choice. Please try again.");
                break;
            }
        }
        System.out.println("\f#--------------------------------------#");
        System.out.println("|        <<CREATE NEW SALE>>           |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Employee:        ");
        personCtr.printEmployeeInfo(employeeID);
        System.out.println("  Customer:        " );
        personCtr.printCustomerInfo(phone);
        System.out.println("  Is this information correct?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");

        boolean goingBack2 = false;
        int chosenOption = 0;
        chosenOption = enterNumber();
        while (!goingBack2) {
            switch (chosenOption) {
                case 1:
                Sale s = saleCtr.createSale(employeeID, phone);
                System.out.println("\f#--------------------------------------#");
                System.out.println("|         <<CREATE NEW SALE>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Employee:        ");
                personCtr.printEmployeeInfo(employeeID);
                System.out.println("  Customer:        " );
                personCtr.printCustomerInfo(phone);
                System.out.println("  Sale ID:         " + s.getSaleID());
                System.out.println("|--------------------------------------|");
                System.out.println("  Sale Created!");
                System.out.println("  Press any key to continue...");
                String henrikIsAGreatTeacher = in.nextLine();
                subMenuManageSale(s.getSaleID());
                goingBack2 = true;
                return;
                case 2:
                System.out.println("  Sale is not created.");
                System.out.println("  Press any key to manage your sale...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack2 = true;
                return;
                default:
                System.out.println("Invalid choice. Please try again.");
                break;
            }
        }
    }

    private void manageSale() {
        saleCtr.printAllSales();
        System.out.println("#--------------------------------------#");
        System.out.println("|           <<MANAGE SALE>>            |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the sale ID:" );
        System.out.println("\n  Type \"back\" to return to the\n  previous menu       ");
        int saleID = checkSaleID();
        if (saleID == -1) {
            return;
        }
        subMenuManageSale(saleID);        
    }
    
    /**
     * The manage sale menu. Only accesable through subMenuCreateSale()
     * 
     * @param saleID    The ID of the sale in question
     */
    private void subMenuManageSale(int saleID) {
        boolean goingBack = false;
        int chosenOption = 0;
        while (!goingBack) {
            saleCtr.printSale(saleID);
            printOptionsStartSaleMenu();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                addOrderLineToSale(saleID);
                System.out.println("  Press any key to continue...");
                String henrikIsAGreatTeacher = in.nextLine();
                break;
                case 2:
                saleCtr.finalizeSale(saleID);
                saleCtr.printSale(saleID);
                System.out.println("  Sale " + saleID + " has been paid and processed.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 3:
                removeOrderLineFromSale(saleID);
                case 4:
                goingBack = true;
                return;
                default:
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * The menu to get all the lists containing sales
     */
    private void subMenuSaleLists() {
        boolean goingBack = false;
        int chosenOption = 0;
        while (!goingBack) {
            printOptionsSaleListsMenu();
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                saleCtr.printAllSales();
                System.out.println("  Press any key to continue...");
                String henrikIsAGreatTeacher = in.nextLine();
                break;
                case 2:
                employeeSaleList();
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                break;
                case 3:
                customerSaleList();
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                break;
                case 4: 
                goingBack = true;
                break;
                default:
                System.out.println("Invalid command. Try again.");
                break;
            }
        }
    }

    /**
     * This is the input for navigating in the menu.
     * Makes sure the program won't crash in case of wrong input.
     * 
     * @return num returns the number put in
     */
    private int enterNumber() {
        while (!in.hasNextInt()) {
            if (in.next().equals("back")) {
                return -1;
            }
            System.out.println("Please enter a number.");
            in.nextLine();
        }
        int num = in.nextInt();
        in.nextLine();              
        return num;
    }

    /**
     * For checking if there are already Sales.
     * 
     * @return true if there are sales.
     * @return false if there aren't sales
     */
    private boolean checkSaleList() {
        if (saleCtr.getAllSales().isEmpty()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * For checking if the customer exists and if not prints out new options for the create Sale method
     * 
     * @return phone    if the customer exists
     */
    private String checkPhoneForSale() {
        String phone = in.nextLine();
        if (personCtr.findCustomer(phone) == null) {
            System.out.println("\f#--------------------------------------#");
            System.out.println("|        <<CREATE NEW SALE>>           |");
            System.out.println("|--------------------------------------|");
            System.out.println("| This Customer doesn't exist.         | ");
            System.out.println("| Options                              |");
            System.out.println("| 1. Re-enter phone number             |");
            System.out.println("| 2. Create new Customer               |");
            System.out.println("| 3. Return to Sale Management Menu    |");
            System.out.println("#--------------------------------------#");
            phone = null;
        }
        return phone;
    }

    /**
     * For checking if the customer exists
     * 
     * @return phone    if the customer exists
     */
    private String checkCustomerPhone() {
        String customerPhone = null;
        do {
            if (customerPhone != null) {
                System.out.println("There is no customer with this number exists. Please enter an existing phone number.");
            }
            customerPhone = in.nextLine();
        } while (personCtr.findCustomer(customerPhone) == null);
        return customerPhone;
    }

    /**
     * For checking if the employee exists and if not prints out new options for the create Sale method
     * 
     * @return employeeID    if the employee exists
     */
    private int checkEmployeeIDForSale(int employeeID) {
        if (personCtr.findEmployee(employeeID) == null) {
            System.out.println("\f#--------------------------------------#");
            System.out.println("|        <<CREATE NEW SALE>>           |");
            System.out.println("|--------------------------------------|");
            System.out.println("| This Employee doesn't exist.         | ");
            System.out.println("| Options                              |");
            System.out.println("| 1. Re-enter ID                       |");
            System.out.println("| 2. Return to Sale Management Menu    |");
            System.out.println("#--------------------------------------#");
            employeeID = -1;
        }
        return employeeID;
    }

    /**
     * For checking if the employee exists
     * 
     * @return employeeID       if the employee exists
     */
    private int checkEmployeeID() {
        Integer employeeID = null;
        do {
            if (employeeID != null) {
                System.out.println("There is no employee with this ID number. Please enter an existing ID.");
            }
            employeeID = enterNumber();
        } while (personCtr.findEmployee(employeeID) == null);
        return employeeID;
    }

    /**
     * For checking if the product exists
     * 
     * @return productID    if the product exists
     */
    private int checkProductID() {
        Integer productID = null;
        do {
            if (productID != null) {
                System.out.println("There is no product with this ID number. Please enter an existing ID.");
            }
            productID = enterNumber();
            if (productID == -1) {
                return -1;
            }
        } while (productCtr.findProductByID(productID) == null);
        return productID;    
    }

    /**
     * For checking if the quanitty is within the bounderies.
     * 
     * @param productID     The ID of the product in question
     * @return quantity     The quantity if the input is correct
     */
    private int checkProductQuantity(int productID) {
        int quantity = in.nextInt();
        int stock = productCtr.findProductByID(productID).getStock();
        while (quantity == 0 || stock < quantity) {
            System.out.println("Quantity needs to be more than 0 and less than product stock: " + stock);
            quantity = in.nextInt();
        }
        return quantity;
    }

    /**
     * For checking if the sale exists
     * 
     * @return saleID    if the slae exists
     */
    private int checkSaleID() {
        Integer saleID = null;
        do {
            if (saleID != null) {
                System.out.println("There is no sale with this ID number. Please enter an existing ID.");
            }
            saleID = enterNumber();
            if (saleID == -1) {
                return -1;
            }
        } while (saleCtr.findSale(saleID) == null);
        return saleID;
    }

    /**
     * Prints out the information of a sale
     */
    private void saleInfoByID() {
        System.out.println("\fPlease enter the sale ID.");
        Integer saleID = checkSaleID();
        if (saleID == null) {
        } else {
            saleCtr.printSale(saleID);
            System.out.print("  Press any key to return back to the Sale Menu.");
            String hoi = in.nextLine();
        }
        
    }

    /**
     * Prints out all the sales of an employee
     */
    private void employeeSaleList() {
        System.out.println("\fPlease enter the employee ID: ");
        int employeeID = checkEmployeeID();
        saleCtr.printEmployeeSales(employeeID);
    }

    /**
     * Prints out all the sales of a customer
     */
    private void customerSaleList() {
        System.out.println("\fPlease enter the customer's phone number: ");
        String phone = checkCustomerPhone();
        saleCtr.printCustomerSales(phone);
    }

    /**
     * Adds an orderline to a sale
     * 
     * @param saleID    The ID of the sale in question
     */
    private void addOrderLineToSale(int saleID) {
        System.out.println(" \f" );
        productCtr.printAllProducts();
        System.out.println("#--------------------------------------#");
        System.out.println("|           <<ADD PRODUCT>>            |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Sale: " + saleID);
        System.out.println("|--------------------------------------|");
        System.out.println(" Please enter the product ID:");
        int productID = checkProductID();

        Product p = productCtr.findProductByID(productID);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|           <<ADD PRODUCT>>            |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Sale: " + saleID);
        System.out.println("  Product: " + p.getProductName());
        System.out.println("|--------------------------------------|");
        System.out.println("  Please enter the product quantity: ");
        int quantity = checkProductQuantity(productID);

        System.out.println("\f#--------------------------------------#");
        System.out.println("|          <<ADD PRODUCT>>             |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Sale:           " + saleID);
        System.out.println("  Product:        " + p.getProductName());
        System.out.println("  Quantity:       " + quantity);
        System.out.println("|--------------------------------------|");
        System.out.println("  " + p.getProductName() + " is added to sale " + saleID);
        String hoi = in.nextLine();
        saleCtr.addOrderLine(saleID, productID, quantity);
    } 

    /**
     * Removes an orderline from a sale
     * 
     * @param saleID    The ID of the sale in question
     */
    private void removeOrderLineFromSale(int saleID) {
        saleCtr.printSale(saleID);
        Sale sale = saleCtr.findSale(saleID);
        System.out.println("#--------------------------------------#");
        System.out.println("|         <<REMOVE PRODUCT>>           |");
        System.out.println("|--------------------------------------|");
        System.out.println(" Please enter the ID of the Product you" );
        System.out.println(" want to remove from the sale:");
        System.out.println("  \n  Type \"back\" to return to the\n  previous menu       ");
        int productID = checkProductID();
        if (productID == -1) {
            subMenuManageSale(saleID);
        }
        
        System.out.println("\f#--------------------------------------#");
        System.out.println("|         <<REMOVE PRODUCT>>           |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Product:      " + productCtr.findProductByID(productID).getProductName());
        System.out.println("  Quantity:     " + sale.findOrderLine(productID).getQuantity());
        System.out.println("  ID:           " + productID);
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this the product you wish to remove?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");

        boolean goingBack = false;
        int chosenOption = 0;
        String henrikIsAGreatTeacher = "";
        while (!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|          <<REMOVE PRODUCT>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Sale ID:      " + saleID);
                System.out.println("  Product:      " + productCtr.findProductByID(productID).getProductName());
                System.out.println("  Quantity:     " + sale.findOrderLine(productID).getQuantity());
                System.out.println("  ID:           " + productID);
                System.out.println("|--------------------------------------|");
                saleCtr.removeOrderLine(saleID, productID);
                System.out.println("  Product has been removed.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|          <<REMOVE PRODUCT>>          |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Sale ID:      " + saleID);
                System.out.println("  Product:      " + productCtr.findProductByID(productID).getProductName());
                System.out.println("  Quantity:     " + sale.findOrderLine(productID).getQuantity());
                System.out.println("  ID:           " + productID);
                System.out.println("|--------------------------------------|");
                System.out.println("  The product is still in the sale. ");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
                break;
            }
        }
    }

    /**
     * Removes a sale for the system
     */
    private void removeSale() {
        saleCtr.printAllSales();
        System.out.println("#--------------------------------------#");
        System.out.println("|           <<REMOVE SALE>>            |");
        System.out.println("|--------------------------------------|");
        System.out.println(" Please enter the ID of the sale being removed");
        System.out.println("  \n  Type \"back\" to return to the\n  previous menu       ");
        int saleID = checkSaleID();
        if (saleID == -1) {
            return;
        }
        Sale sale = saleCtr.findSale(saleID);
        System.out.println("\f#--------------------------------------#");
        System.out.println("|           <<REMOVE SALE>>            |");
        System.out.println("|--------------------------------------|");
        System.out.println("  Sale ID:  " + sale.getSaleID());
        System.out.println("  Employee:" );
        System.out.println("  ID:       " + sale.getEmployeeID());
        System.out.println("  Name:     " + personCtr.findEmployee(sale.getEmployeeID()).getName());
        System.out.println("  Customer: ");
        System.out.println("  Name:     " + personCtr.findCustomer(sale.getCustomerPhone()).getName());
        System.out.println("  Phone:    " + sale.getCustomerPhone());
        System.out.println("|--------------------------------------|");
        System.out.println("  Is this the sale you wish to remove?");
        System.out.println("  1. Yes");
        System.out.println("  2. No");

        boolean goingBack = false;
        int chosenOption = 0;
        String henrikIsAGreatTeacher = "";
        while (!goingBack) {
            chosenOption = enterNumber();
            switch (chosenOption) {
                case 1:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|           <<REMOVE SALE>>            |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Sale ID:  " + sale.getSaleID());
                System.out.println("  Employee:" );
                System.out.println("  ID:       " + sale.getEmployeeID());
                System.out.println("  Name:     " + personCtr.findEmployee(sale.getEmployeeID()).getName());
                System.out.println("  Customer: ");
                System.out.println("  Name:     " + personCtr.findCustomer(sale.getCustomerPhone()).getName());
                System.out.println("  Phone:    " + sale.getCustomerPhone());
                System.out.println("|--------------------------------------|");
                saleCtr.removeSale(saleID);
                System.out.println("  Sale has been removed.");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                case 2:
                System.out.println("\f#--------------------------------------#");
                System.out.println("|           <<REMOVE SALE>>            |");
                System.out.println("|--------------------------------------|");
                System.out.println("  Sale ID:  " + sale.getSaleID());
                System.out.println("  Employee:" );
                System.out.println("  ID:       " + sale.getEmployeeID());
                System.out.println("  Name:     " + personCtr.findEmployee(sale.getEmployeeID()).getName());
                System.out.println("  Customer: ");
                System.out.println("  Name:     " + personCtr.findCustomer(sale.getCustomerPhone()).getName());
                System.out.println("  Phone:    " + sale.getCustomerPhone());
                System.out.println("|--------------------------------------|");
                System.out.println("  The sale is still in the system. ");
                System.out.println("  Press any key to continue...");
                henrikIsAGreatTeacher = in.nextLine();
                goingBack = true;
                break;
                default:
                System.out.println("Invalid choice. Please try again");
                break;
            }
        }
    }
}
