package GUILayer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JToggleButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JList;
import javax.swing.JScrollBar;
import java.awt.Color;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import java.awt.Toolkit;
import CtrLayer.ProductCtr;
import ModelLayer.Product;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.HashSet;
import javax.swing.JComboBox;

public class UpdateProduct extends JFrame {
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private ProductCtr productCtr = new ProductCtr();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateProduct frame = new UpdateProduct();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateProduct() {
		
		setTitle("Update a product");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUpdateAProduct = new JLabel("Which product do you wish to update? ");
		lblUpdateAProduct.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblUpdateAProduct.setBounds(25, 20, 300, 50);
		contentPane.add(lblUpdateAProduct);
		
		JLabel label = new JLabel("Product name: ");
		label.setFont(new Font("Tahoma", Font.ITALIC, 20));
		label.setBounds(25, 130, 155, 50);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Product stock: ");
		label_1.setFont(new Font("Tahoma", Font.ITALIC, 20));
		label_1.setBounds(25, 200, 155, 50);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Product price: ");
		label_2.setFont(new Font("Tahoma", Font.ITALIC, 20));
		label_2.setBounds(25, 270, 155, 50);
		contentPane.add(label_2);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(225, 130, 280, 50);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(225, 200, 280, 50);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(225, 270, 280, 50);
		contentPane.add(textField_2);
		
		ArrayList<String> productNames = new ArrayList<String>();
		ArrayList<Integer> productIds = new ArrayList<Integer>();

		for (Product prod : productCtr.getAllProducts()) {
			productNames.add(prod.getProductName());
			productIds.add(prod.getProductID());
		}
		 
		JComboBox comboBox = new JComboBox(productNames.toArray());
        comboBox.setBounds(300, 25, 241, 58);
        contentPane.add(comboBox);
		


		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedItemId;
				if(((String)comboBox.getSelectedItem() != null) && !textField.getText().equals("") && !textField_1.getText().equals("") && !textField_2.getText().equals("")) {
					selectedItemId = productIds.get(comboBox.getSelectedIndex());
					productCtr.updateProductName(selectedItemId, textField.getText());
					productCtr.updateStock(selectedItemId, Integer.parseInt(textField_2.getText()));
					productCtr.updatePrice(selectedItemId, Double.parseDouble(textField_1.getText()));
					JOptionPane.showMessageDialog(null, "The product " + productCtr.findProductByID(selectedItemId).getProductName() + " was updated.");
					dispose();
					//	UpdateProductPopUp upu = new UpdateProductPopUp();
					//	upu.setVisible(true);	
				}
				else
				{
					JOptionPane.showMessageDialog(null, "One or more input parametres are incorrect.");
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(124, 340, 140, 50);
		contentPane.add(btnNewButton);
		
		JButton btnGoBack = new JButton("Go back");
		btnGoBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
//				UpdateProductPopUp.main(null);
				contentPane.setVisible(false);
				dispose();
//				ProductGUI.main(null);
			}
		});
		
		btnGoBack.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnGoBack.setBounds(370, 340, 200, 50);
		contentPane.add(btnGoBack);
		
		
	}
}
