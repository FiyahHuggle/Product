package GUILayer;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import ModelLayer.Product;
import CtrLayer.ProductCtr;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JComboBox;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.HashSet;

public class RemoveProduct extends JFrame {

	private ProductCtr productCtr = new ProductCtr();
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RemoveProduct frame = new RemoveProduct();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

    public RemoveProduct() {
        setTitle("Remove product");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 350, 450);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

		ArrayList<String> productNames = new ArrayList<String>();

		for (Product prod : productCtr.getAllProducts()) {
			productNames.add(prod.getProductName());
		}
		 
		JComboBox comboBox = new JComboBox(productNames.toArray());
        comboBox.setBounds(50, 25, 241, 58);
        contentPane.add(comboBox);
	
        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(35, 315, 97, 25);
		contentPane.add(btnDelete);
		btnDelete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if((String)comboBox.getSelectedItem() != null) {
					productCtr.removeProduct(productCtr.findProductByName((String)comboBox.getSelectedItem()).getProductID());
					JOptionPane.showMessageDialog(null, "The product " + comboBox.getSelectedItem() + " has been removed.");
					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "No product was found.");
				}
			}
		});

        JButton btnCancel = new JButton("Cancel");
        btnCancel.setBounds(194, 315, 97, 25);
		contentPane.add(btnCancel);
		btnCancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
    }
}